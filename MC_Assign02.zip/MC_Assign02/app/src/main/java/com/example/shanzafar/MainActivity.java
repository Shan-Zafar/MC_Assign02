package com.example.shanzafar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText number;
    TextView euro;
    TextView pound;
    TextView dollar;

    public void unitConversionCalculator(View view){
        String numberToConvert = number.getText().toString();
        int convertToDollar = Integer.parseInt(numberToConvert);
        int convertToEuro = Integer.parseInt(numberToConvert);
        int convertToPound = Integer.parseInt(numberToConvert);

        convertToDollar = convertToDollar * 174;
        convertToEuro = convertToEuro * 203;
        convertToPound = convertToPound * 239;

       String convertDollar =  Integer.toString(convertToDollar);
       String convertEuro =  Integer.toString(convertToEuro);
       String convertPound = Integer.toString(convertToPound);

        dollar.setText(numberToConvert + " Rs = $" + convertDollar );
        pound.setText(numberToConvert + " Rs = £" + convertPound);
        euro.setText(numberToConvert + " Rs = €" + convertEuro);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        number = (EditText) findViewById(R.id.etNumber);
        euro = (TextView) findViewById(R.id.euro);
        pound = (TextView) findViewById(R.id.pound);
        dollar = (TextView) findViewById(R.id.dollar);
    }
}